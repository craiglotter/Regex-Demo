Revision History:

Initial Version:

7/8/2002	Released initial version
7/12/2002	Fixed bug where using the Add button blew up
8/6/2002	Fixed incorrect parsing bug on multiple line strings.
			This led to strings using '$' only matching on the 
			last string in a group, but not on intermediate ones.
